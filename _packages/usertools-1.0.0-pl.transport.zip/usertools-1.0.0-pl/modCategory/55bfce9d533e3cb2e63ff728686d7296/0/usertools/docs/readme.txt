--------------------
Extra: userTools
--------------------
Version: 1.0.0-pl
Released: March 24, 2017
Since: March 24, 2017
Author: David Pede <dev@tasianmedia.com> <https://twitter.com/davepede>
Copyright: (C) 2017 David Pede. All rights reserved. <dev@tasianmedia.com>

A User toolkit Extra for MODX Revolution.

Official Documentation:
https://rtfm.modx.com/extras/revo/userTools

GitHub Repository:
https://github.com/tasianmedia/userTools

Bugs & Feature Requests:
https://github.com/tasianmedia/userTools/issues

License:
Released under the GNU General Public License; either version 2 of the License, or (at your option) any later version.
http://www.gnu.org/licenses/gpl.html